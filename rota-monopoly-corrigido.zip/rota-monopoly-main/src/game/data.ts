import type { Evento, Tile } from "./types";

export const CATEGORIA_LABEL = {
  armazem: "Armazém",
  caminhao: "Caminhão",
  porto: "Porto",
  ferrovia: "Ferrovia",
} as const;

export const EVENTOS: Evento[] = [
  { texto: "Uma grande entrega foi concluída antes do prazo.", delta: 12000 },
  { texto: "Contrato emergencial de transporte gerou receita extra.", delta: 18000 },
  { texto: "A manutenção de uma frota pesada ficou mais cara.", delta: -9000 },
  { texto: "Uma rota alternativa reduziu seus custos operacionais.", delta: 7000 },
  { texto: "Atrasos no terminal causaram despesas inesperadas.", delta: -6000 },
  { texto: "Novo cliente fechou um contrato de logística.", delta: 15000 },
  { texto: "Uma carga precisou de seguro adicional.", delta: -5000 },
  { texto: "Sua empresa recebeu um bônus por eficiência logística.", delta: 10000 },
];

export const TABULEIRO: Tile[] = [
  { kind: "inicio", nome: "Base RotaLog" },
  { kind: "prop", nome: "Armazém Central", preco: 10000, aluguel: 1000, categoria: "armazem", sigla: "ARM" },
  { kind: "evento", nome: "Mercado em Movimento" },
  { kind: "prop", nome: "Garagem Sul", preco: 12000, aluguel: 1200, categoria: "caminhao", sigla: "CAM" },
  { kind: "taxa", nome: "Taxa Rodoviária", valor: 7000 },
  { kind: "prop", nome: "Porto Leste", preco: 16000, aluguel: 1600, categoria: "porto", sigla: "POR" },
  { kind: "bonus", nome: "Bônus de Eficiência", valor: 8000 },

  { kind: "prop", nome: "Centro Norte", preco: 18000, aluguel: 1800, categoria: "armazem", sigla: "ARM" },
  { kind: "evento", nome: "Boletim Logístico" },
  { kind: "prop", nome: "Frota Expressa", preco: 20000, aluguel: 2000, categoria: "caminhao", sigla: "CAM" },
  { kind: "parada", nome: "Parada Técnica" },
  { kind: "prop", nome: "Ferrovia Central", preco: 22000, aluguel: 2200, categoria: "ferrovia", sigla: "FER" },
  { kind: "taxa", nome: "Fiscalização de Carga", valor: 9000 },

  { kind: "prop", nome: "Terminal Oeste", preco: 24000, aluguel: 2400, categoria: "porto", sigla: "POR" },
  { kind: "evento", nome: "Mercado em Movimento" },
  { kind: "prop", nome: "Hub de Distribuição", preco: 26000, aluguel: 2600, categoria: "armazem", sigla: "ARM" },
  { kind: "bonus", nome: "Contrato Premium", valor: 12000 },
  { kind: "prop", nome: "Frota Regional", preco: 28000, aluguel: 2800, categoria: "caminhao", sigla: "CAM" },
  { kind: "parada", nome: "Área de Descanso" },
  { kind: "prop", nome: "Ferrovia Sul", preco: 30000, aluguel: 3000, categoria: "ferrovia", sigla: "FER" },

  { kind: "taxa", nome: "Imposto Logístico", valor: 11000 },
  { kind: "prop", nome: "Porto Industrial", preco: 32000, aluguel: 3200, categoria: "porto", sigla: "POR" },
  { kind: "evento", nome: "Boletim Logístico" },
  { kind: "prop", nome: "Mega Hub RotaLog", preco: 36000, aluguel: 3600, categoria: "armazem", sigla: "ARM" },
];

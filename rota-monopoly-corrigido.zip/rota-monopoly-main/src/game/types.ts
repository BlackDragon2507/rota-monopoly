export type Categoria = "armazem" | "caminhao" | "porto" | "ferrovia";

export type Tile =
  | {
      kind: "prop";
      nome: string;
      preco: number;
      aluguel: number;
      categoria: Categoria;
      sigla: string;
    }
  | { kind: "inicio"; nome: string }
  | { kind: "evento"; nome: string }
  | { kind: "taxa"; nome: string; valor: number }
  | { kind: "bonus"; nome: string; valor: number }
  | { kind: "parada"; nome: string };

export interface Evento {
  texto: string;
  delta: number;
}

export interface Jogador {
  id: number;
  nome: string;
  cor: string;
  dinheiro: number;
  posicao: number;
  cpu: boolean;
  falido: boolean;
  pontos: number;
  rodadas: number;
}

export const CORES = [
  "var(--player-1)",
  "var(--player-2)",
  "var(--player-3)",
  "var(--player-4)",
] as const;
